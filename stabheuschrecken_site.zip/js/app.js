// Accordion behavior: close others when one opens (progressive enhancement)
document.addEventListener('click', (e) => {
  const summary = e.target.closest('summary');
  if(!summary) return;
  const current = summary.parentElement;
  if(current.tagName.toLowerCase() !== 'details') return;
  const acc = current.parentElement;
  if(!acc || !acc.querySelectorAll) return;
  acc.querySelectorAll('details[open]').forEach(d => {
    if(d !== current) d.removeAttribute('open');
  });
});